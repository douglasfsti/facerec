#ifndef OUTPUT_FILE_H
#define OUTPUT_FILE_H

#define OUT_FILE_CMD_TAKE           1
#define OUT_FILE_CMD_FILENAME       2

#endif
